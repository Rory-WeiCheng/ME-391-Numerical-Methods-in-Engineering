function result = int_2_7(n)
%输入一个行向量，每个元素代表一个n的值
%输出一个行向量，每个元素对应一个近似积分的结果
x = (0.005:0.01:0.995)'*ones(1,numel(n));
result = sum(x.^n./(x+5))*0.01;
end
