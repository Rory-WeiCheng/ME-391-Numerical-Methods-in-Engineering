clc,clear

randvec = rand(1,10000);
% profile on
tic
vec1 = vecSort_1(randvec);
t1 = toc

tic
vec2 = vecSort_2(randvec);
t2 = toc

tic
vec3 = sort(randvec);
t3 = toc
% profile viewer
% profile off
% t1/t3;t2/t3;
%检验排序结果是否正确
isCorrect1 = sum(vec1 == vec3) == 10000;
isCorrect2 = sum(vec2 == vec3) == 10000;

function vec = vecSort_1(vec)
%插入排序，每次循环将序列分成[序列1，最小值，序列2]
for i = 1:numel(vec)-1
    [v,id] = min(vec(i:end));           %找出最小值
%     vec(i:i+id-1) = [v,vec(i:i+id-2)];  %插入
    vec(i+1:i+id-1) = vec(i:i+id-2);%序列1右移一个位置
    vec(i) = v;                     %最小值放到序列最左边
end
end

function vec = vecSort_2(vec)
%快速排序
if numel(vec)>1
    middle = median(vec);
    left = vec(vec < middle);
    right = vec(vec > middle);
    middle = vec(vec == middle);
    vec = [vecSort_2(left),middle,vecSort_2(right)];
end
end


