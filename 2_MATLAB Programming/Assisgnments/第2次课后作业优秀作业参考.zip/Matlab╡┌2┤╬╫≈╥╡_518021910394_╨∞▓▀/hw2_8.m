clc,clear

n = 10.^(2:7);
varpi = zeros(1,6);

for i = 1:numel(n)
    num = n(i);
    x = rand(1,num);
    y = rand(1,num);        %随机撒点
    r2 = x.^2 + y.^2;       %判断点是否在圆内
    varpi(i) = 4*sum(r2<=1)/num;
end
semilogx([10^2,10^7],[pi,pi],n,varpi,'LineWidth',2)
xlabel('采样点数');ylabel('计算结果');
legend('实际值','估计值');
title('蒙特卡罗方法估计\pi值');
grid on