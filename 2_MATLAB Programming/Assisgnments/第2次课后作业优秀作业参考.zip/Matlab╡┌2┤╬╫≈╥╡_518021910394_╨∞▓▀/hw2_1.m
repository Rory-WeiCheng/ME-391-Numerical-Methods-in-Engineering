x = @(t) exp(t/4).*cos(t);
y = @(t) exp(t/4).*sin(t);

t = 0:pi/100:pi*6;
plot(x(t),y(t),'LineWidth',2)
axis equal
grid on
xlabel('x');ylabel('y');title('对数螺线');