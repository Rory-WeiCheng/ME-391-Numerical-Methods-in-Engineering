clc,clear

%% 方法一
xn1 = int_2_7(1:100);
log1 = log(abs(xn1));

%% 方法二
xn2 = zeros(1,100);
xn2(1) = int_2_7(1);
for n = 2:100
    xn2(n) = 1/n - 5*xn2(n-1);
end
log2 = log(abs(xn2));

%% 方法三
xn3 = zeros(1,100);
xn3(100) = int_2_7(100);
for n = 100:-1:2
    xn3(n-1) = (1/n - xn3(n))/5;
end
log3 = log(abs(xn3));

%% 画图
n = 1:100;
fig = plot(n,[log1;log2;log3],'LineWidth',2)
legend('方法一','方法二','方法三')
xlabel('n');ylabel('log(|x_n|)');
title('result')

%% 验证
% XN = [[1./(1:100),0];[0,xn2*5];[xn2,0]];
% number = zeros(4,100);
% number(1,:) = 1./(1:100);
% for i = 2:100
%     number(2,i) = xn1(i) + 5*xn1(i-1);
%     number(3,i) = xn2(i) + 5*xn2(i-1);
%     number(4,i) = xn3(i) + 5*xn3(i-1);
% end