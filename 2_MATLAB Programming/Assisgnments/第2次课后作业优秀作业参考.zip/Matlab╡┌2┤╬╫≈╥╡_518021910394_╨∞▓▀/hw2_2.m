clc,clear

%% 从文件中读取变量
% opts = detectImportOptions('assignment2.xlsx');
% preview('assignment2.xlsx',opts)
[ID,Gender,Date,Height] = readvars('assignment2.xlsx');
% whos ID Gender Date Height
Gender = categorical(Gender);
Date = datetime(Date,'InputFormat','yyyy-MM');
TotalNum = length(ID);
% % filename = 'assignment2.xlsx';
% % T = readtable(filename);
% % T = readtable(filename,'PreserveVariableNames',true)

%% 统计男女比例
male = sum(Gender == '男');
female = TotalNum - male;
[den,num] = rat(male/female);
str_1 = sprintf('男女比例为%d:%d',den,num);

%% 统计出生日期
date2000_2 = datetime(2000,3,1);
early = sum(Date < date2000_2);
percentage = 100*early/TotalNum;
str_2 = sprintf('出生年月不晚于2000-2的比例为%d%%',percentage);

%% 按照身高从矮到高排序，并给出排序后的学号序列
[sort_h,sort_id] = sort(Height);

%% 输出结果
disp(str_1)
disp(str_2)
disp('按身高排序的结果为:')
disp(ID(sort_id)')