clc,clear

%% 将文件数据作为矩阵读取
filename = 'assignment3.txt';
x = readmatrix(filename)

%% 结果计算
x = reshape(x',1,[])
% x = x(:)';
Y = [x;exp(x)];

%% 结果输出
fid = fopen('assignment3_output.txt','w');
fprintf(fid,'%.2f %.4f\n',Y);
fclose(fid)