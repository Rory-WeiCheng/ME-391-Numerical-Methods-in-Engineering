clc,clear

format long
a = zeros(6,1);
b = zeros(6,1);
for i = 1:6
    a(i) = round(sqrt(2021),i);
    b(i) = round(sqrt(2020),i);
end

x = round(a - b,6);
y = round(1./(a + b),6);
result = [x,y];
error = x - y;

%% 遇到的问题
%保留尾数的结果应当如下，但在命令行显示的b矩阵不正确，在工作空间是正确的
% b = [44.9
%     44.94
%     44.944
%     44.9444
%     44.94441
%     44.944410];
    