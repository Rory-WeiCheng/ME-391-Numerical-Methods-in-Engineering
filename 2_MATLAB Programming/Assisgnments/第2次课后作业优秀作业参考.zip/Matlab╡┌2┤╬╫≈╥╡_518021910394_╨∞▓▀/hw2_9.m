clc,clear

f = [-5,-3];
A = [2 1
    1 1];
b = [10,8];
lb = [0,0];
ub = [10,7];
x = linprog(f,A,b,[],[],lb,ub)