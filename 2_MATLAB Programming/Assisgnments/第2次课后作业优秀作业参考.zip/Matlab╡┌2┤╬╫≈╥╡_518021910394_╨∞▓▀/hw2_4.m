clc,clear

F = zeros(100,1);
F(1) = 1;
F(2) = 1;
for i = 3:100
    F(i) = F(i-1) + F(i-2);
end
disp('F100=')
disp(sym(F(100)))
% 使用sym和vpa转化结果最后几位好像不是真值