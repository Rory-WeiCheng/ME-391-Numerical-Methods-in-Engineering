clc,clear

% disp('n should be a row vector');
% n = input('n = ');
% result = int_2_7(n)

result = int_2_7(1:100)'

% disp(['x_n = ',num2str(result)])