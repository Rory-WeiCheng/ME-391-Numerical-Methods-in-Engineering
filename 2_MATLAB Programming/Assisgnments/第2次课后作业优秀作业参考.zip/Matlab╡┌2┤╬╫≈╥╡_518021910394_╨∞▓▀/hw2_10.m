clc,clear
N = 10;
maze = [0 0 1 1 1 0 1 1 1 1
        1 0 1 1 1 0 0 0 0 0
        1 0 1 1 1 0 1 1 0 1
        1 0 0 0 0 0 1 1 0 1
        1 0 1 0 0 1 1 1 0 1
        1 0 1 1 0 1 1 1 0 1
        1 0 1 1 0 1 1 1 0 1
        0 0 1 1 0 0 1 1 0 1
        1 1 1 1 1 0 0 0 0 0
        1 1 1 1 1 1 1 1 1 0];

if [N,N]~=size(maze)
    error('迷宫矩阵的维度不正确')
else
    len_path = get_path(N,maze)
end



function f = get_path(N,maze)
%% 从终点出发，计算所有格子到终点的距离
current = zeros(N);         %current标记当前位置
current(end) = 1;           %从终点出发，所以current(N,N)=1
map = 1-maze;               %maze标记无障碍物、没有走过的格点为1
map(end) = 0;               
dir = [0,1,0;1,0,1;0,1,0];
path = current;             %记录所有格点到终点的距离
i = 1;
while path(1) == 0
    i = i+1;
    next = convn(current,dir,'same').*map;
    current = next>0;
    map = map - current;
    path = path + current*i;
end
f = i-1;

%% 从起点出发，按梯度下降方向寻路
current = zeros(N);         %current标记当前位置
current(1) = 1;             %从起点出发，所以current(N,N)=1
ind = [N^2,zeros(1,i-2),1];           %ind是路线的坐标序列
% Smap = zeros(N,N,i);
% Smap = Smap + current;
% Smap(N,N,i) = 1;
j = i-1;
map = path == reshape((2:j),1,1,j-1);
while j > 1
    next = convn(current,dir,'same').*map(:,:,j-1);
    ind(j) = find(next,1);
    current(ind(j+1)) = 0;
    current(ind(j)) = 1;
%     Smap(:,:,i-j:end) = Smap(:,:,i-j:end) + current;
    j = j-1;
end
[row,col] = ind2sub([N,N],flip(ind));

%% 绘图
imshow(maze,'InitialMagnification','fit')
draw_path = animatedline(col(1),row(1),'Color','b','LineWidth',2);
for t = 2:i
    pause(0.3)
    addpoints(draw_path,col(t),row(t));
%     draw_path = line(col(1:t),row(1:t),'LineWidth',2);
%     drawnow
%    frame=getframe(gcf);  
%    im=frame2im(frame); 
%    [I,map]=rgb2ind(im,20);
%    if t == 2
%        imwrite(I,map,'get_path.gif','gif', 'Loopcount',inf,'DelayTime',0.3);%第一次必须创建！
%    else
%        imwrite(I,map,'get_path.gif','gif','WriteMode','append','DelayTime',0.3);
%    end
end
end

