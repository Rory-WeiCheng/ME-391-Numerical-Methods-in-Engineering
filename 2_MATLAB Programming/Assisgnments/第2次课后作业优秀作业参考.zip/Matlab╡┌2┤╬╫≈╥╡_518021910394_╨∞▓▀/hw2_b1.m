clc,clear

%% 输入参数
node_num = 7;
A=[7 5 4;7 6 1; 7 3 7;5 2 2;6 2 4; 6 3 4; 6 4 2; 3 1 2; 2 1 1; 4 1 3];

%% 变量定义
% matrixA表示有向图的邻接矩阵
% 第i行表示i到其他各点的代价
matrixA = full(sparse(A(:,2),A(:,1),A(:,3),node_num,node_num));
matrixA(matrixA==0 & ~eye(node_num,'logical')) = inf;
% B用于存储计算结果
% 前n行代表了n次运算，其中，前n列代表1到各点的最小代价，最后一列代表加入的节点
% 最后一行代表最短路径的连接方式
B = [matrixA(1,:),1;
    zeros(node_num-1,node_num+1);
    ones(1,node_num),nan];
% node_list记录各节点的使用状态，即是否被考虑进计算结果中
node_list = [0,ones(1,node_num-1)];


%% 求解
for i = 2:node_num
    node = find(node_list);     %找出没有顾及的节点
    [M,I] = min(B(i-1,node));   %找出其中代价最小的节点，准备加入结果中
    node_ind = node(I);
    [M2,I2] = min([B(i-1,1:node_num);matrixA(node_ind,:)+M]);%将经由新节点到其他点的代价与原记录比较，取最小值
    B(i,1:end-1) = M2;          %更新包含i个节点的结果
    B(i,end) = node_ind;        %B(i,:) = [M2,node_ind];
    node_list(node_ind) = 0;    %将考虑过的点从list中剔除
    B(end,I2==2) = node_ind;    %记录最短路径的两个端点
end
min_cost = B(node_num,node_num);
min_path = 7;
while min_path(1)>1
    min_path = [B(end,min_path(1)),min_path];
end
disp(['最短路径为',replace(num2str(min_path),'  ','->')]);
disp(['其对应的最小代价为',num2str(min_cost)]);