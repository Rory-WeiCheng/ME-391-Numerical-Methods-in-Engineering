vec=rand(1,10000);
tic;
vec1=vec;
for i=1:10000
    sign=1;
    for j=1:9999
        if vec1(j)>vec1(j+1)
            temp=vec1(j);
            vec1(j)=vec1(j+1);
            vec1(j+1)=temp;
            sign=0;
        end
    end
    if sign
        break;
    end
end
t1=toc;
tic;
vec2=vec;
for i=1:10000
    tempvec=vec2(i:10000);
    pom=find(tempvec==min(tempvec));
    temp=tempvec(pom);
    vec2(pom+i-1)=vec2(i);
    vec2(i)=temp;
end
t2=toc;
tic;
vec3=vec;
vec3=sort(vec3);
t3=toc;
fprintf('t1=%f;t2=%f;t3=%f.\n',t1,t2,t3);
        
        
        
        
        
        
        