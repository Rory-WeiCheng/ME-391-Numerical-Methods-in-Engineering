%% 原始算法（没有精度保障）：用于估计最终结果
% F0=0;
% F1=1;
% for i=1:100
%     tmp=F0+F1;
%     F0=F1;
%     F1=tmp;
% end
% F0
%% 检测程序：计算最后一位
% F=zeros(1,100);
% F(1)=1; F(2)=1;
% for i=3:100
%     F(i)=mod(F(i-1)+F(i-2),10);
% end
% F=F(100);
%% 计算程序：计算真值
M=intmax('int64');
m=double(M);
N=int64(floor(log10(m)));
B=10^N;
F0=[int64(0),int64(0)];
F1=[int64(0),int64(1)];
for i=1:100
    if B-F0(2)<F1(2)
        tmp=[F0(1)+F1(1)+1,F0(2)-B+F1(2)];
        F0=F1;
        F1=tmp;
        continue;
    end
    tmp=F0+F1;
    F0=F1;
    F1=tmp;
end
F0